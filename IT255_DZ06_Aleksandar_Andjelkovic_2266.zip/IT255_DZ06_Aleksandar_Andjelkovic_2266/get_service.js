$.ajax('http://jsonplaceholder.typicode.com/albums/76', {
  method: 'GET'
}).then(function(data) {
    $('.userId').append(data.userId);
    $('.id').append(data.id);
    $('.title').append(data.title); 
});