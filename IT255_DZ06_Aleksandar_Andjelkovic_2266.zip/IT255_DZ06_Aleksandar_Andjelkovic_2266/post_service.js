$.ajax('http://jsonplaceholder.typicode.com/albums', {
  method: 'POST',
  data: {
    title: 'randomTitle',
    body: 'randomBody',
    userId: 76
  }
}).then(function(data) {
    $('.userId').append(data.userId);
    $('.id').append(data.id);
    $('.title').append(data.title); 
});
